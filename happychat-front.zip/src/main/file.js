const fs = require('fs')
const fse = require('fs-extra')
const NODE_ENV = process.env.NODE_ENV
const path = require('path')
const { app, ipcMain, shell, dialog } = require('electron')
const { exec } = require('child_process')
const FormData = require('form-data')
const axios = require('axios')
const express = require('express')
const expressServer = express()

import store from './store'
import { selectByMessageId } from './db/ChatMessage'
import { selectUserSetting, updateSysSetting } from './db/UserSetting'
import { getWindow } from './windowProxy'
const moment = require('moment')
moment.locale('zh-cn', {})

const cover_image_suffix = '_cover.png'
const image_suffix = '.png'
const ffprobePath = '/assets/ffprobe.exe'
const ffmpegPath = '/assets/ffmpeg.exe'
const notifyPath = '/assets/notify.mp3'

const getResourcePath = () => {
  let resourcePath = app.getAppPath()
  if (NODE_ENV != 'development') {
    resourcePath = path.dirname(app.getAppPath('exe' + '/resources'))
  }
  return resourcePath
}

const getFFprobePath = () => {
  return path.join(getResourcePath(), ffprobePath)
}

const getFFmpegPath = () => {
  return path.join(getResourcePath(), ffmpegPath)
}

const execCommand = (command) => {
  return new Promise((resolve, reject) => {
    exec(command, (err, stdout, stderr) => {
      if (err) {
        console.log('执行命令失败', err)
      }
      resolve(stdout)
    })
  })
}

const arePathsEqual = (path1, path2) => {
  const resolvedPath1 = path.resolve(path1).replace(/\\/g, '/')
  const resolvedPath2 = path.resolve(path2).replace(/\\/g, '/')

  return resolvedPath1 === resolvedPath2
}

const saveFileToLocal = (messageId, filePath, fileType) => {
  return new Promise(async (resolve, reject) => {
    let savePath = await getLocalFilePath('chat', false, messageId)
    let ffmpegPath = getFFmpegPath()
    let coverPath = null
    // console.log(filePath, savePath)
    fs.copyFileSync(filePath, savePath)
    if (fileType == 0 || fileType == 1) {
      let command = `${getFFprobePath()} -v error -select_streams v:0 -show_entries stream=codec_name "${filePath}"`
      let result = await execCommand(command)
      result = result.replaceAll('\r\n', '')
      result = result.substring(result.indexOf('=') + 1)
      let codec = result.substring(0, result.indexOf('['))
      if ('hevc' == codec) {
        //将h265转成h264
        command = `${ffmpegPath} -y -i "${filePath}" -c:v libx264 -crf 20 "${savePath}"`
        await execCommand(command)
      }
      //生成缩略图
      coverPath = savePath + cover_image_suffix
      command = `${ffmpegPath} -i "${savePath}" -y -vframes 1 -vf "scale=min(170\\,iw*min(170/iw\\,170/ih)):min(170\\,ih*min(170/iw\\,170/ih))" "${coverPath}"`
      await execCommand(command)
    }
    //文件保存到本地后,上传到服务器
    uploadFile(messageId, savePath, coverPath)
    resolve()
  })
}

const getDomain = () => {
  return NODE_ENV !== 'development' ? store.getData('prodDomain') : store.getData('devDomain')
}

const uploadFile = (messageId, savePath, coverPath) => {
  const formData = new FormData()
  formData.append('messageId', messageId)
  // console.log(savePath)
  formData.append('file', fs.createReadStream(savePath))
  if (coverPath) {
    formData.append('cover', fs.createReadStream(coverPath))
  }
  const url = `${getDomain()}/api/chat/uploadFile`
  const token = store.getUserData('token')
  const config = { headers: { 'Content-Type': 'multipart/form-data', 'token': token } }
  axios
    .post(url, formData, config)
    .then((response) => {})
    .catch((error) => {
      console.log('文件上传失败', error)
    })
}

const mkdirs = (filePath) => {
  if (!fs.existsSync(filePath)) {
    const parentDir = path.dirname(filePath)
    if (parentDir != filePath) {
      mkdirs(parentDir)
    }
    fs.mkdirSync(filePath)
  }
}

// 生成本地文件保存的目录
const getLocalFilePath = (partType, showCover, fileId) => {
  return new Promise(async (resolve, reject) => {
    let localFolder = store.getUserData('localFileFolder')
    let localPath = null
    if (partType == 'avatar') {
      localFolder = localFolder + '/avatar/'
      if (!fs.existsSync(localFolder)) {
        mkdirs(localFolder)
      }
      localPath = localFolder + fileId + image_suffix
    } else if (partType == 'chat') {
      //查询消息
      let messageInfo = await selectByMessageId(fileId)
      const date = moment(Number.parseInt(messageInfo.sendTime)).format('YYYY-MM')
      localFolder = localFolder + '/' + date
      //创建用户文件夹，保存文本
      if (!fs.existsSync(localFolder)) {
        mkdirs(localFolder)
      }
      let fileSuffix = messageInfo.fileName
      fileSuffix = fileSuffix.substring(fileSuffix.lastIndexOf('.'))
      localPath = localFolder + '/' + fileId + fileSuffix
    } else if (partType == 'tmp') {
      localFolder = localFolder + '/tmp'
      if (!fs.existsSync(localFolder)) {
        mkdirs(localFolder)
      }
      localPath = localFolder + '/' + fileId
    } else if (partType == 'notify') {
      localPath = path.join(getResourcePath(), notifyPath)
    }
    if (showCover) {
      localPath += cover_image_suffix
    }

    resolve(localPath)
  })
}

let server = null
const startServer = (port) => {
  server = expressServer.listen(port, () => {
    console.log(`Local App listening at http://localhost:${port}`)
  })
}

const closeServer = () => {
  if (server) {
    server.close()
  }
}

const FILE_CONTENT_TYPE = {
  0: 'image/',
  1: 'video/',
  2: 'audio/',
  3: 'application/octet-stream'
}

expressServer.get('/file', async (req, resp) => {
  let { partType, fileType, fileId, showCover, forceGet } = req.query
  if (!partType || !fileId) {
    resp.send('请求参数错误')
    return
  }
  showCover = showCover == undefined ? false : Boolean(showCover)
  const localPath = await getLocalFilePath(partType, showCover, fileId)
  console.log('localPath', localPath)
  if (!fs.existsSync(localPath) || forceGet == 'true') {
    if (forceGet == 'true' || partType == 'avatar') {
      await downloadFile(fileId, true, localPath + cover_image_suffix, partType)
    }
    await downloadFile(fileId, showCover, localPath, partType)
  }
  const fileSuffix = localPath.substring(localPath.lastIndexOf('.') + 1)
  let contentType = FILE_CONTENT_TYPE[fileType] + fileSuffix
  console.log('contentType', contentType)
  //允许所有跨域
  resp.setHeader('Access-Control-Allow-Origin', '*')
  resp.setHeader('Content-Type', contentType)
  if (showCover) {
    fs.createReadStream(localPath).pipe(resp)
    return
  }
  let stat = fs.statSync(localPath)
  let fileSize = stat.size
  let range = req.headers.range
  console.log('range', range)
  if (range) {
    let parts = range.replace(/bytes=/, '').split('-')
    let start = parts[0] ? parseInt(parts[0], 10) : undefined
    let end = parts[1] ? parseInt(parts[1], 10) : undefined
    if (isNaN(start) || isNaN(end)) {
      start = 0
      end = fileSize - 1
    }
    end = end > fileSize - 1 ? fileSize - 1 : end
    let chunksize = end - start + 1

    let stream = fs.createReadStream(localPath, { start, end })
    resp.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': contentType
    })
    stream.pipe(resp)
  } else {
    const head = {
      'Content-Length': fileSize,
      'Content-Type': contentType
    }
    console.log(head)
    resp.writeHead(200, head)
    fs.createReadStream(localPath).pipe(resp)
  }
  return
})

//从后端服务器下载图片
const downloadFile = (fileId, showCover, savePath, partType) => {
  showCover = showCover + ''
  let url = `${getDomain()}/api/chat/downloadFile`
  const token = store.getUserData('token')
  return new Promise(async (resolve, reject) => {
    const config = {
      responseType: 'stream',
      headers: {
        'Content-Type': 'multipart/form-data',
        'token': token
      }
    }
    let response = await axios.post(
      url,
      {
        fileId,
        showCover
      },
      config
    )
    const folder = savePath.substring(0, savePath.lastIndexOf('/'))
    mkdirs(folder)
    const stream = fs.createWriteStream(savePath)
    if (response.headers['content-type'] == 'application/json') {
      let resourcePath = getResourcePath()
      if (partType == 'avatar') {
        fs.createReadStream(resourcePath + '/assets/user.png').pipe(stream)
      } else {
        fs.createReadStream(resourcePath + '/assets/404.png').pipe(stream)
      }
    } else {
      // console.log('文件下载成功')
      response.data.pipe(stream)
    }
    stream.on('finish', () => {
      stream.close()
      resolve()
    })
  })
}

const createCover = (filePath) => {
  return new Promise(async (resolve, reject) => {
    let ffmpegPath = getFFmpegPath()
    let avatarPath = await getLocalFilePath('avatar', false, store.getUserId() + '_temp')
    let command = `${ffmpegPath} -i "${filePath}" "${avatarPath}" -y`
    await execCommand(command)

    //生成缩略图
    let coverPath = await getLocalFilePath('avatar', false, store.getUserId() + '_temp_cover')
    command = `${ffmpegPath} -i "${filePath}" -y -vframes 1 -vf "scale=min(170\\,iw*min(170/iw\\,170/ih)):min(170\\,ih*min(170/iw\\,170/ih))" "${coverPath}"`
    await execCommand(command)
    resolve({
      avatarStream: fs.readFileSync(avatarPath),
      coverStream: fs.readFileSync(coverPath)
    })
  })
}

const saveAs = async ({ partType, fileId }) => {
  let fileName = ''
  if (partType == 'avatar') {
    fileName = fileId + image_suffix
  } else if (partType == 'chat') {
    let messageInfo = await selectByMessageId(fileId)
    fileName = messageInfo.fileName
  }
  const localPath = await getLocalFilePath(partType, false, fileId)
  const options = {
    title: '保存文件',
    defaultPath: fileName
  }
  let result = await dialog.showSaveDialog(options)
  if (result.canceled || result.filePath == '') {
    return
  }
  const filePath = result.filePath
  fs.copyFileSync(localPath, filePath)
}

const saveClipBoardFile = async (file) => {
  const fileSuffix = file.name.substring(file.name.lastIndexOf('.'))
  const filePath = await getLocalFilePath('tmp', false, 'tmp' + fileSuffix)
  let byteArray = file.byteArray
  const buffer = Buffer.from(byteArray)
  fs.writeFileSync(filePath, buffer)
  return {
    size: byteArray.length,
    name: file.name,
    path: filePath
  }
}

const showUserFileFolder = async (partType, fileId) => {
  const directoryPath = await getLocalFilePath(partType, false, fileId)
  console.log('directoryPath', directoryPath)
  shell
    .openPath(directoryPath)
    .then(() => {
      console.log('目录已打开')
    })
    .catch((error) => {
      console.error('打开目录时出错:', error)
    })
}

const openLocalFolder = async () => {
  let sysSettingInfo = await selectUserSetting(store.getUserId())
  console.log(sysSettingInfo)
  let sysSetting = JSON.parse(sysSettingInfo.sysSetting)
  const localFileFolder = sysSetting.localFileFolder

  if (!fs.existsSync(localFileFolder)) {
    mkdirs(localFileFolder)
  }

  shell.openPath('file:///' + localFileFolder)
}

const changeFolder = async () => {
  const userId = store.getUserId()
  let sysSettingInfo = await selectUserSetting(userId)

  let sysSetting = JSON.parse(sysSettingInfo.sysSetting)

  let localFileFolder = sysSetting.localFileFolder
  if (!fs.existsSync(localFileFolder)) {
    mkdirs(localFileFolder)
  }
  const options = {
    properties: ['openDirectory'],
    defaultPath: localFileFolder
  }
  let result = await dialog.showOpenDialog(options)
  if (result.canceled) {
    return
  }
  const newFileFolder = result.filePaths[0]
  if (!arePathsEqual(newFileFolder, localFileFolder)) {
    getWindow('main').webContents.send('copyingCallback')
    await fse.copy(localFileFolder + '/' + userId, newFileFolder + '/' + userId)
  }

  sysSetting.localFileFolder = newFileFolder + '\\'
  const sysJson = JSON.stringify(sysSetting)
  await updateSysSetting(sysJson)
  store.setUserData('localFileFolder', sysSetting.localFileFolder + userId)
  getWindow('main').webContents.send('getSyssettingCallback', sysJson)
}

const downloadUpdate = async (id, fileName) => {
  let url = `${store.getData('domain')}/api/update/download`
  const token = store.getUserData('token')
  const config = {
    responseType: 'stream',
    headers: {
      'Content-Type': 'multipart/form-data',
      'token': token
    },
    onDownloadProgress(progress) {
      const loaded = progress.loaded
      getWindow('main').webContents.send('updateDownloadCallback', loaded)
    }
  }
  const response = await axios.post(url, { id }, config)
  const localFile = await getLocalFilePath(null, false, fileName)
  const stream = fs.createWriteStream(localFile)
  response.data.pipe(stream)
  stream.on('finish', async () => {
    stream.close()
    //开始安装
    const command = `${localFile}`
    execCommand(command)
  })
}

export {
  saveFileToLocal,
  startServer,
  closeServer,
  createCover,
  saveAs,
  saveClipBoardFile,
  showUserFileFolder,
  openLocalFolder,
  changeFolder,
  downloadUpdate
}
