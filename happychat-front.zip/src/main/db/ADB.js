const fs = require('fs')
const sqlite3 = require('sqlite3').verbose()
const os = require('os')
const NODE_ENV = process.env.NODE_ENV
import { add_tables, add_index, alter_tables } from './dbTables'
const userDir = os.homedir()
const dbFolder = userDir + (NODE_ENV === 'development' ? '/.happychattest/' : '/.happychat/')
if (!fs.existsSync(dbFolder)) {
  fs.mkdirSync(dbFolder)
}

const db = new sqlite3.Database(dbFolder + 'local.db')
const globalColumnsMap = {}

const createTable = () => {
  return new Promise(async (resolve, reject) => {
    for (const item of add_tables) {
      await db.run(item)
    }

    for (const item of add_index) {
      await db.run(item)
    }

    // for (const item of alter_tables) {
    //   const fieldList = await queryAll(`PRAGMA table_info(${item.tableName})`, [])
    //   const field = fieldList.some((row) => row.name === item.field)
    //   if (!field) {
    //     await db.run(sql)
    //   }
    // }
    resolve()
  })
}

const run = (sql, params) => {
  return new Promise(async (resolve, reject) => {
    const stmt = db.prepare(sql)
    stmt.run(params, function (err, row) {
      if (err) {
        resolve('操作数据库失败')
      }
      resolve(this.changes)
    })
    stmt.finalize()
  })
}

const insert = (sqlOp, tableName, supportData) => {
  const columnsMap = globalColumnsMap[tableName]
  const dbColumns = []
  const params = []
  for (let item in supportData) {
    if (supportData[item] != undefined && columnsMap[item] != undefined) {
      dbColumns.push(columnsMap[item])
      params.push(supportData[item])
    }
  }
  const prepare = '?'.repeat(dbColumns.length).split('').join(',')
  const sql = `${sqlOp} ${tableName}(${dbColumns.join(',')}) values(${prepare})`
  return run(sql, params)
}

const insertOrReplace = (tableName, supportData) => {
  return insert('insert or replace into', tableName, supportData)
}

const insertOrIgnore = (tableName, supportData) => {
  return insert('insert or ignore into', tableName, supportData)
}
const update = (tableName, supportData, paramData) => {
  const columnsMap = globalColumnsMap[tableName]
  const dbColumns = []
  const params = []
  const whereColumns = []
  //数据库属性和更新参数
  for (let item in supportData) {
    if (
      supportData[item] != undefined &&
      supportData[item] != null &&
      columnsMap[item] != undefined
    ) {
      dbColumns.push(`${columnsMap[item]}=?`)
      params.push(supportData[item])
    }
  }

  //条件属性
  for (let item in paramData) {
    if (paramData[item]) {
      params.push(paramData[item])
      whereColumns.push(`${columnsMap[item]}=?`)
    }
  }
  const sql = `update ${tableName} set ${dbColumns.join(',')} ${whereColumns.length > 0 ? 'where ' : ''} ${whereColumns.join(' and ')}`
  return run(sql, params)
}

const queryCount = (sql, params) => {
  return new Promise(async (resolve, reject) => {
    const stmt = db.prepare(sql)
    stmt.get(params, function (err, row) {
      if (err) {
        resolve([])
      }
      resolve(Array.from(Object.values(row))[0])
    })
    stmt.finalize()
  })
}

const queryOne = (sql, params) => {
  return new Promise(async (resolve, reject) => {
    const stmt = db.prepare(sql)
    stmt.get(params, function (err, row) {
      if (err) {
        resolve([])
      }
      resolve(convertDbToJs(row))
    })
    stmt.finalize()
  })
}

const queryAll = (sql, params) => {
  return new Promise(async (resolve, reject) => {
    const stmt = db.prepare(sql)
    stmt.all(params, function (err, row) {
      if (err) {
        resolve([])
      }
      if (row == null || row == undefined) {
        return
      }
      row.forEach((item, index) => {
        row[index] = convertDbToJs(item)
      })
      resolve(row)
    })
    stmt.finalize()
  })
}

//数据库属性转成驼峰
const convertDbToJs = (data) => {
  if (!data) {
    return null
  }
  const result = {}
  for (let item in data) {
    result[toCamelCase(item)] = data[item]
  }
  // console.log(result)
  return result
}

const toCamelCase = (str) => {
  return str.replace(/_([a-z])/g, function (match, p1) {
    return String.fromCharCode(p1.charCodeAt(0) - 32)
  })
}

const initTableColumnsMap = async () => {
  let sql = `select name from sqlite_master where type = 'table' and name != 'sqlite_sequence';`
  let tables = await queryAll(sql, [])
  for (let i = 0; i < tables.length; i++) {
    sql = `PRAGMA table_info(${tables[i].name});`
    let columns = await queryAll(sql, [])
    const columnsMapItem = {}
    for (let j = 0; j < columns.length; j++) {
      columnsMapItem[toCamelCase(columns[j].name)] = columns[j].name
    }
    globalColumnsMap[tables[i].name] = columnsMapItem
  }
  // console.log(globalColumnsMap)
}

const init = () => {
  db.serialize(async () => {
    await createTable()
    await initTableColumnsMap()
  })
}

init()

export {
  run,
  insert,
  insertOrReplace,
  insertOrIgnore,
  update,
  queryAll,
  queryOne,
  queryCount,
  createTable
}
