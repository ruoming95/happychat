import {
  run,
  insert,
  insertOrReplace,
  insertOrIgnore,
  update,
  queryAll,
  queryOne,
  queryCount
} from './ADB'

import store from '../store'

const selectUserSessionByContactId = (contactId) => {
  let sql = 'select * from chat_session_user where user_id = ? and contact_id = ?'
  return queryOne(sql, [store.getUserId(), contactId])
}

const addChatSession = (sessionInfo) => {
  sessionInfo.userId = store.getUserId()
  if (!sessionInfo.nodeReadCount) {
    sessionInfo.nodeReadCount = 0
  }
  insertOrIgnore('chat_session_user', sessionInfo)
}

const updateChatSession = (sessionInfo) => {
  const paramData = {
    userId: store.getUserId(),
    contactId: sessionInfo.contactId
  }
  const updateInfo = Object.assign({}, sessionInfo)
  //置为空，不更新
  updateInfo.userId = null
  updateInfo.contactId = null
  return update('chat_session_user', updateInfo, paramData)
}

const saveOrUpdateChatSession = (sessionId, sessionInfo) => {
  return new Promise(async (resolve, reject) => {
    try {
      let dbSessionInfo = await selectUserSessionByContactId(sessionInfo.contactId)
      console.log('dbSessionInfo', dbSessionInfo)
      console.log('sessionInfo', sessionInfo)
      if (dbSessionInfo) {
        await updateSessionInfoMessage(sessionId, sessionInfo)
      } else {
        await addChatSession(sessionInfo)
      }
      resolve()
    } catch (error) {
      reject()
    }
  })
}

const saveOrUpdateChatSessionBatch = (chatSessionList) => {
  return new Promise(async (resolve, reject) => {
    try {
      for (let i = 0; i < chatSessionList.length; i++) {
        const sessionInfo = chatSessionList[i]
        sessionInfo.status = 1
        let sessionData = await selectUserSessionByContactId(sessionInfo.contactId)
        if (sessionData) {
          await updateChatSession(sessionInfo)
        } else {
          await addChatSession(sessionInfo)
        }
      }
      resolve()
    } catch (error) {
      reject()
    }
  })
}

const updateNoReadCount = ({ contactId, nodeReadCount }) => {
  if (nodeReadCount == undefined || nodeReadCount == null) {
    nodeReadCount = 0
  }
  let sql =
    'update chat_session_user set no_read_count = no_read_count + ? where user_id = ? and contact_id = ?'
  return run(sql, [nodeReadCount, store.getUserId(), contactId])
}

const selectUserSessionList = () => {
  let sql = 'select * from chat_session_user where user_id = ? and status = 1'
  return queryAll(sql, [store.getUserId()])
}

const delChatSession = (contactId) => {
  const paramData = {
    userId: store.getUserId(),
    contactId
  }
  const sessionInfo = {
    status: 0
  }
  return update('chat_session_user', sessionInfo, paramData)
}

const topChatSession = (contactId, topType) => {
  const paramData = {
    userId: store.getUserId(),
    contactId
  }
  const sessionInfo = {
    topType
  }
  return update('chat_session_user', sessionInfo, paramData)
}

const updateGroupName = async (contactId, groupName) => {
  let paramData = {
    userId: store.getUserId(),
    contactId
  }

  let sessionInfo = {
    contactName: groupName
  }
  return new Promise(async (resolve, reject) => {
    try {
      await update('chat_session_user', sessionInfo, paramData)
      resolve()
    } catch (error) {
      reject()
    }
  })
}

const updateSessionInfoMessage = async (
  currentSessionId,
  { sessionId, contactName, lastMessage, lastReceiveTime, contactId, memberCount }
) => {
  const params = [lastMessage, lastReceiveTime]
  let sql = 'update chat_session_user set last_message = ?, last_receive_time = ?,status = 1'
  if (contactName) {
    sql = sql + ',contact_name = ?'
    params.push(contactName)
  }

  if (memberCount != null) {
    sql = sql + ',member_count = ?'
    params.push(memberCount)
  }

  //未选中当前会话，未读消息 + 1
  if (sessionId != currentSessionId) {
    sql = sql + ',no_read_count = no_read_count + 1'
  }

  sql = sql + ' where user_id = ? and contact_id = ?'
  params.push(store.getUserId())
  params.push(contactId)
  console.log(params)
  return run(sql, params)
}

const cleanNoReadCount = (contactId) => {
  let sql = 'update chat_session_user set no_read_count = 0 where user_id = ? and contact_id = ?'
  return run(sql, [store.getUserId(), contactId])
}

const updateStatus = (contactId) => {
  let paramData = {
    userId: store.getUserId(),
    contactId: contactId
  }
  let sessionInfo = {
    status: 1
  }
  return update('chat_session_user', sessionInfo, paramData)
}
export {
  saveOrUpdateChatSessionBatch,
  saveOrUpdateChatSession,
  updateNoReadCount,
  selectUserSessionList,
  delChatSession,
  topChatSession,
  updateSessionInfoMessage,
  cleanNoReadCount,
  selectUserSessionByContactId,
  updateGroupName,
  updateStatus
}
