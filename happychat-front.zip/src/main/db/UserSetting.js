import {
  run,
  insert,
  insertOrReplace,
  insertOrIgnore,
  update,
  queryAll,
  queryOne,
  queryCount
} from './ADB'
const os = require('os')
import store from '../store'
import { startServer } from '../file'
const userDir = os.homedir()
const updateContactNoReadCount = ({ userId, noReadCount }) => {
  return new Promise(async (resolve, reject) => {
    if (noReadCount == 0) {
      resolve()
      return
    }
    let sql = ''
    if (noReadCount) {
      sql = 'update user_setting set contact_no_read = contact_no_read + ? where user_id = ?'
    } else {
      noReadCount = 0
      sql = 'update user_setting set contact_no_read = ? where user_id = ?'
    }
    await run(sql, [noReadCount, userId])
    resolve()
  })
}

const getLocalUser = () => {
  let sql = 'select email from user_setting where email is not null'
  return queryAll(sql, [])
}

const addUserSetting = async (userId, email) => {
  let sql = 'select max(server_port) server_port from user_setting'
  let { serverPort } = await queryOne(sql, [])
  if (serverPort == null) {
    serverPort = 10240
  } else {
    serverPort++
  }
  const sysSetting = {
    localFileFolder: userDir + '\\.happychat\\fileStorage\\'
  }
  sql = 'select * from user_setting where user_id = ?'
  const userInfo = await queryOne(sql, [userId])
  let serverPortResult = null
  let localFileFolder = sysSetting.localFileFolder + userId
  if (userInfo) {
    await update('user_setting', { email: email }, { userId: userId })
    serverPortResult = userInfo.serverPort
    localFileFolder = JSON.parse(userInfo.sysSetting).localFileFolder + userId
  } else {
    await insertOrIgnore('user_setting', {
      userId: userId,
      email: email,
      sysSetting: JSON.stringify(sysSetting),
      contactNoRead: 0,
      serverPort: serverPort
    })
    serverPortResult = serverPort
  }
  //启动本地服务
  startServer(serverPortResult)
  store.setUserData('localServerPort', serverPortResult)
  store.setUserData('localFileFolder', localFileFolder)
}

const selectUserSetting = (userId) => {
  let sql = 'select * from user_setting where user_id = ?'
  return queryOne(sql, [userId])
}

const updateSysSetting = (sysSetting) => {
  let data = {
    sysSetting
  }

  let paramData = {
    userId: store.getUserId()
  }
  return update('user_setting', data, paramData)
}

export {
  updateContactNoReadCount,
  addUserSetting,
  getLocalUser,
  selectUserSetting,
  updateSysSetting
}
