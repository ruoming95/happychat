import { app, shell, BrowserWindow, ipcMain, session } from 'electron'
import { join } from 'path'
import { electronApp, optimizer, is } from '@electron-toolkit/utils'
import icon from '../../resources/icon.png?asset'
import store from './store'
import { initWs, closeWs } from './WebSocketClient'
import {
  updateContactNoReadCount,
  addUserSetting,
  getLocalUser,
  selectUserSetting
} from './db/UserSetting.js'
import {
  createCover,
  saveFileToLocal,
  saveAs,
  saveClipBoardFile,
  closeServer,
  showUserFileFolder,
  changeFolder,
  openLocalFolder,
  downloadUpdate
} from './file.js'
import {
  saveOrUpdateChatSessionBatch,
  updateNoReadCount,
  selectUserSessionList,
  delChatSession,
  topChatSession,
  updateSessionInfoMessage,
  cleanNoReadCount,
  updateStatus
} from './db/ChatSessionUser'
import { selectMessageList, saveMessage, updateMessage } from './db/ChatMessage'
import { delWindow, getWindow, saveWindow } from './windowProxy'
const NODE_ENV = process.env.NODE_ENV

const onLoginOrRegister = (callback) => {
  ipcMain.on('loginOrRegister', (e, isLogin) => {
    callback(isLogin)
  })
}

const onLoginSuccess = (callback) => {
  ipcMain.on('openChat', (e, config) => {
    //保存状态数据到主进程store里
    store.initUserId(config.userId)
    store.setUserData('token', config.token)
    //保存用户设置
    addUserSetting(config.userId, config.email)
    callback(config)
    initWs(config, e.sender)
  })
}

const onReLogin = (callback) => {
  ipcMain.on('reLogin', async (e) => {
    callback()
    e.sender.send('reLogin')
    closeWs()
    closeServer()
  })
}

const winTitleOp = (callback) => {
  ipcMain.on('winTitleOp', (e, data) => {
    callback(e, data)
  })
}

//e是渲染进程
const onSetLocalStore = () => {
  ipcMain.on('setLocalStore', (e, { key, value }) => {
    store.setData(key, value)
  })
}

const onGetLocalStore = () => {
  ipcMain.on('getLocalStore', (e, key) => {
    e.sender.send('getLocalStoreCallback', store.getData(key))
  })
}

const onLoadSessionData = () => {
  ipcMain.on('loadSessionData', async (e) => {
    //数据库操作
    const dataList = await selectUserSessionList()
    e.sender.send('loadSessionDataCallback', dataList)
  })
}

const onTopChatSession = () => {
  ipcMain.on('topChatSession', (e, { contactId, topType }) => {
    topChatSession(contactId, topType)
  })
}

const onDelChatSession = () => {
  ipcMain.on('delChatSession', (e, contactId) => {
    delChatSession(contactId)
  })
}

const onLoadChatMessage = () => {
  ipcMain.on('loadChatMessage', async (e, data) => {
    const result = await selectMessageList(data)
    e.sender.send('loadChatMessageCallback', result)
  })
}

const onAddLocalMessage = () => {
  ipcMain.on('addLocalMessage', async (e, data) => {
    await saveMessage(data)
    //TOD 保存文件
    if (data.messageType == 5) {
      await saveFileToLocal(data.messageId, data.filePath, data.fileType)

      //保存到本地，更新装台
      const updateInfo = {
        status: 1
      }
      await updateMessage(updateInfo, { messageId: data.messageId })
    }
    //更新chat_session
    data.lastReceiveTime = data.sendTime
    //TODD更新会话
    updateSessionInfoMessage(store.getUserData('currentSessionId'), data)
    e.sender.send('addLocalMessageCallback', { status: 1, messageId: data.messageId })
  })
}

const onSaveSessionInfo = () => {
  ipcMain.on('saveSessionInfo', (e, { contactId, sessionId }) => {
    if (sessionId) {
      // console.log('ipc里当前会话Id', sessionId)
      store.setUserData('currentSessionId', sessionId)
      //清空未读数
      cleanNoReadCount(contactId)
    } else {
      store.deleteUserData('currentSessionId')
    }
  })
}

const onCreateCover = () => {
  ipcMain.on('createCover', async (e, filePath) => {
    // console.log(filePath)
    const stream = await createCover(filePath)
    e.sender.send('createCoverCallback', stream)
  })
}

const onCreateNewWindow = () => {
  ipcMain.on('createNewWindow', (e, config) => {
    openWindow(config)
  })
}

const openWindow = ({ windowId, title = '', path, width = 960, height = 720, data }) => {
  const localServerPort = store.getUserData('localServerPort')
  data.localServerPort = localServerPort
  width = Math.round(width)
  height = Math.round(height)
  let newWindow = getWindow(windowId)
  if (!newWindow) {
    newWindow = new BrowserWindow({
      icon: icon,
      width: width,
      height: height,
      fullscreen: false,
      fullscreenable: false,
      maximizable: false,
      autoHideMenuBar: true,
      titleBarStyle: 'hidden',
      resizable: false,
      frame: false,
      transparent: true,
      hasShadow: false,
      webPreferences: {
        preload: join(__dirname, '../preload/index.js'),
        sandbox: false,
        contextIsolation: false
      }
    })
    saveWindow(windowId, newWindow)
    newWindow.setMinimumSize(800, 434)
    if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
      newWindow.loadURL(`${process.env['ELECTRON_RENDERER_URL']}/index.html#${path}`)
    } else {
      newWindow.loadFile(join(__dirname, `../renderer/index.html`), { hash: `${path}` })
    }

    if (NODE_ENV == 'development') {
      newWindow.webContents.openDevTools()
    }
    newWindow.on('ready-to-show', () => {
      newWindow.setTitle(title)
      newWindow.show()
    })
    newWindow.once('show', () => {
      setTimeout(() => {
        newWindow.webContents.send('pageInitData', data)
      }, 500)
    })
    newWindow.on('close', () => {
      delWindow(windowId)
    })
  } else {
    newWindow.show()
    newWindow.setSkipTaskbar(false)
    newWindow.webContents.send('pageInitData', data)
  }
}

const onSaveAs = () => {
  ipcMain.on('saveAs', async (e, data) => {
    await saveAs(data)
    setTimeout(() => {
      e.sender.send('saveAsCallback')
    }, 500)
  })
}

const onSaveClipBoardFile = () => {
  ipcMain.on('saveClipBoardFile', async (e, data) => {
    const result = await saveClipBoardFile(data)
    e.sender.send('saveClipBoardFileCallback', result)
  })
}

const onGetLocalUser = () => {
  ipcMain.on('getLocalUser', async (e) => {
    let userList = await getLocalUser()
    userList.sort((a, b) =>
      a.email.toLowerCase().localeCompare(b.email.toLowerCase(), undefined, { sensitivity: 'base' })
    )
    e.sender.send('getLocalUserCallback', userList)
  })
}

const onLoadContactApply = () => {
  ipcMain.on('loadContactApply', async (e) => {
    let userId = store.getUserId()
    let result = await selectUserSetting(userId)
    let contactNoRead = 0
    if (result != null) {
      contactNoRead = result.contactNoRead
    }
    e.sender.send('loadContactApplyCallback', contactNoRead)
  })
}

const onUpdateContactNoReadCount = () => {
  ipcMain.on('updateContactNoReadCount', async (e) => {
    await updateContactNoReadCount({ userId: store.getUserId() })
  })
}

const onReLoadChatSession = () => {
  ipcMain.on('reLoadChatSession', async (e, contactId) => {
    await updateStatus(contactId)
    const chatSessionList = await selectUserSessionList()
    e.sender.send('reLoadChatSessionCallback', { contactId, chatSessionList })
  })
}

const onChatMessageFileDetail = () => {
  ipcMain.on('chatMessageFileDetail', async (e, data) => {
    if (data.fileType == '3') {
      console.log(data.messageId)
      await showUserFileFolder('chat', data.messageId)
    }
  })
}

const onChangeFolder = () => {
  ipcMain.on('changeFolder', async (e) => {
    changeFolder()
  })
}

const onOpenLocalFolder = () => {
  ipcMain.on('openLocalFolder', async (e) => {
    openLocalFolder()
  })
}

const onGetSyssetting = () => {
  ipcMain.on('getSyssetting', async (e) => {
    let result = await selectUserSetting(store.getUserId())
    let sysSetting = result.sysSetting
    e.sender.send('getSyssettingCallback', sysSetting)
  })
}

const onOpenUrl = () => {
  ipcMain.on('openUrl', (e, { url }) => {
    shell.openExternal(url)
  })
}

const onDownloadUpdate = () => {
  ipcMain.on('downloadUpdate', (e, { id, fileName }) => {
    downloadUpdate(id, fileName)
  })
}

export {
  onLoginOrRegister,
  onLoginSuccess,
  winTitleOp,
  onSetLocalStore,
  onGetLocalStore,
  onLoadSessionData,
  onDelChatSession,
  onTopChatSession,
  onLoadChatMessage,
  onAddLocalMessage,
  onSaveSessionInfo,
  onCreateCover,
  onCreateNewWindow,
  onSaveAs,
  onSaveClipBoardFile,
  onReLogin,
  onGetLocalUser,
  openWindow,
  onLoadContactApply,
  onUpdateContactNoReadCount,
  onReLoadChatSession,
  onChatMessageFileDetail,
  onChangeFolder,
  onOpenLocalFolder,
  onGetSyssetting,
  onOpenUrl,
  onDownloadUpdate
}
