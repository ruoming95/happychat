import WebSocket from 'ws'
import store from './store.js'
import {
  saveOrUpdateChatSessionBatch,
  saveOrUpdateChatSession,
  selectUserSessionList,
  selectUserSessionByContactId,
  updateGroupName,
  updateNoReadCount
} from './db/ChatSessionUser.js'
import { saveMessage, saveMessageBatch, updateMessage } from './db/ChatMessage.js'
import { updateContactNoReadCount, addUserSetting } from './db/UserSetting.js'

const NODE_ENV = process.env.NODE_ENV

let ws = null
let wsUrl = null
let sender = null
let isReConnect = null
let lockWs = true
let reConnectTimes = 0

const initWs = (config, _sender) => {
  wsUrl = `${NODE_ENV === 'development' ? store.getData('devWsDomain') : store.getData('prodWsDomain')}?token=${config.token}`
  reConnectTimes = 5
  sender = _sender
  isReConnect = true
  createWs(wsUrl)
}

const createWs = (wsUrl) => {
  if (wsUrl == null) {
    return
  }
  ws = new WebSocket(wsUrl)
  ws.onopen = () => {
    console.log('WebSocket 连接成功')
    reConnectTimes = 5
    ws.send('heart beat')
  }

  ws.onmessage = async (e) => {
    let message = JSON.parse(e.data)
    let messageType = message.messageType
    console.log('收到服务器消息：', message)
    switch (messageType) {
      //ws连接成功
      case 0:
        // 保存会话信息
        const chatSessionList = message.extendData.chatSessionList
        const chatMessageList = message.extendData.chatMessageList
        //保存会话信息到本地
        await saveOrUpdateChatSessionBatch(chatSessionList)
        //保存消息到本地
        await saveMessageBatch(chatMessageList)
        //保存联系人申请数量
        await updateContactNoReadCount({
          userId: store.getUserId(),
          noReadCount: message.extendData.applyCount
        })
        sender.send('receiveMessage', message)
        break
      case 4: //好友申请
        await updateContactNoReadCount({ userId: store.getUserId(), noReadCount: 1 })
        sender.send('receiveMessage', message)
        break
      // 文件上传完成操作
      case 6:
        await updateMessage({ status: message.status }, { messageId: message.messageId })
        sender.send('receiveMessage', message)
        break
      case 7: //强制下线
        sender.send('receiveMessage', message)
        closeWs()
        break
      case 10: //修改群昵称
        await updateGroupName(store.getUserId(), message.extendData)
        sender.send('receiveMessage', message)
        break
      case 1: //添加好友
      case 2: //文本消息
      case 3: //创建群
      case 5: //图片视频消息
      case 8: //解散群了
      case 9: //好友加入群聊
      case 11: //退出群聊
      case 12: //踢出群聊
      case 13: //添加好友
        //群聊且是自己发
        // console.log('message', message)
        if (store.getUserId() == message.sendUserId && message.contactType == 1) {
          break
        }
        const sessionInfo = {}
        if (message.extendData && typeof message.extendData == 'object') {
          Object.assign(sessionInfo, message.extendData)
        } else {
          // 发送消息，新建会话到本地 添加好友除外
          Object.assign(sessionInfo, message)
          if (message.contactType == 0 && messageType != 1) {
            sessionInfo.contactName = message.sendUserNickName
          }
          sessionInfo.lastReceiveTime = message.sendTime
        }
        if (message.messageType == 1 && message.messageType == 13) {
          sessionInfo.noReadCount = 1
        }

        if (messageType == 9 || messageType == 11 || messageType == 12) {
          //更新membercount
          sessionInfo.memberCount = message.memberCount
        }

        await saveOrUpdateChatSession(store.getUserData('currentSessionId'), sessionInfo)
        await saveMessage(message)

        const dbSessionInfo = await selectUserSessionByContactId(message.contactId)
        message.extendData = dbSessionInfo
        //退出群聊不发消息
        if (message.messageType == 11 && message.extendData.userId == store.getUserId()) {
          break
        }
        sender.send('receiveMessage', message)
        break
    }
  }

  ws.onclose = () => {
    console.log('WebSocket 连接已关闭')
    reConnect()
  }

  ws.onerror = (error) => {
    console.error('WebSocket 出现错误:', error)
    reConnect()

    ws.close()
  }

  const reConnect = () => {
    if (!isReConnect) {
      console.log('连接断开')
      return
    }
    if (ws != null) {
      ws.close()
    }
    if (lockWs) {
      return
    }
    lockWs = true
    if (reConnectTimes > 0) {
      console.log('准备重连，剩余次数' + reConnectTimes + '次')
      reConnectTimes--
      setTimeout(() => {
        createWs()
        lockWs = false
      }, 5000)
    } else {
      console.log('连接超时')
    }
  }
  let interval = setInterval(() => {
    if (ws != null && ws.readyState == 1) {
      // console.log('发送心跳')
      ws.send('heart beat')
    }
  }, 5000)
}

const closeWs = () => {
  console.log('WebSocket 连接已关闭')
  ws.close()
}

export { initWs, closeWs }
