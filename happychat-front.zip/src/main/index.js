import { app, shell, BrowserWindow, Menu, Tray } from 'electron'
import { join } from 'path'
import { electronApp, optimizer, is } from '@electron-toolkit/utils'
import icon from '../../resources/icon.png?asset'
import { delWindow, getWindow, saveWindow } from './windowProxy'
import {
  onLoginOrRegister,
  onLoginSuccess,
  winTitleOp,
  onSetLocalStore,
  onGetLocalStore,
  onLoadSessionData,
  onDelChatSession,
  onTopChatSession,
  onLoadChatMessage,
  onAddLocalMessage,
  onSaveSessionInfo,
  onCreateCover,
  onCreateNewWindow,
  onSaveAs,
  onSaveClipBoardFile,
  onReLogin,
  onGetLocalUser,
  openWindow,
  onLoadContactApply,
  onUpdateContactNoReadCount,
  onReLoadChatSession,
  onChatMessageFileDetail,
  onChangeFolder,
  onOpenLocalFolder,
  onGetSyssetting,
  onOpenUrl,
  onDownloadUpdate
} from './ipc'
import { createTable } from './db/ADB'
const NODE_ENV = process.env.NODE_ENV

const login_width = 300
const login_height = 370
const register_height = 490

function createWindow() {
  // Create the browser window.
  const mainWindow = new BrowserWindow({
    icon: icon,
    width: login_width,
    height: login_height,
    show: false,
    autoHideMenuBar: true,
    titleBarStyle: 'hidden',
    resizable: false,
    frame: false,
    transparent: true,
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      contextIsolation: false
    }
  })

  saveWindow('main', mainWindow)

  if (NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools()
  }

  // mainWindow.webContents.openDevTools()

  mainWindow.on('ready-to-show', () => {
    mainWindow.show()
    mainWindow.setTitle('开心交友')
  })

  // 托盘
  const tray = new Tray(icon)
  const contextMenu = [
    {
      label: '结束应用程序',
      click: function () {
        app.exit()
      }
    }
  ]

  const menu = Menu.buildFromTemplate(contextMenu)
  tray.setToolTip('开心交友')
  tray.setContextMenu(menu)
  tray.on('click', () => {
    mainWindow.setSkipTaskbar(false)
    if (mainWindow.isVisible()) {
      mainWindow.hide()
    } else {
      mainWindow.show()
    }
  })

  //监听登录注册
  onLoginOrRegister((isLogin) => {
    // console.log('收到渲染进程消息', isLogin)
    mainWindow.setResizable(true)
    if (isLogin) {
      mainWindow.setSize(login_width, login_height)
    } else {
      mainWindow.setSize(login_width, register_height)
    }
    mainWindow.setResizable(false)
  })

  onLoginSuccess((config) => {
    mainWindow.setResizable(true)
    mainWindow.setSize(850, 800)
    mainWindow.center()
    mainWindow.setMaximizable(true)
    mainWindow.setMinimumSize(800, 600)

    //管理后台窗口的操作
    if (config.admin) {
      contextMenu.unshift({
        label: '管理后台',
        click: function () {
          openWindow({
            windowId: 'admin',
            title: '管理后台',
            path: '/admin',
            width: config.screenWidth * 0.9,
            height: config.screenHeight * 0.9,
            data: {
              token: config.token
            }
          })
        }
      })
    }

    contextMenu.unshift({
      label: '用户界面',
      click: function () {
        if (mainWindow.isVisible()) {
          mainWindow.hide()
        } else {
          mainWindow.show()
        }
      }
    })
    tray.setContextMenu(Menu.buildFromTemplate(contextMenu))
  })

  winTitleOp((e, { action, data }) => {
    const webContents = e.sender
    const win = BrowserWindow.fromWebContents(webContents)
    switch (action) {
      case 'close': {
        if (data.closeType == 0) {
          win.close()
        } else {
          win.setSkipTaskbar(true)
          win.hide()
        }
        break
      }
      case 'minimize': {
        win.minimize()
        break
      }
      case 'maximize': {
        win.maximize()
        break
      }
      case 'unmaximize': {
        win.unmaximize()
        break
      }
      case 'top': {
        win.setAlwaysOnTop(data.top)
        break
      }
    }
  })

  mainWindow.webContents.setWindowOpenHandler((details) => {
    shell.openExternal(details.url)
    return { action: 'deny' }
  })

  if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
    mainWindow.loadURL(process.env['ELECTRON_RENDERER_URL'])
  } else {
    mainWindow.loadFile(join(__dirname, '../renderer/index.html'))
  }

  onSetLocalStore()

  onGetLocalStore()

  onLoadSessionData()

  onDelChatSession()

  onTopChatSession()

  onLoadChatMessage()

  onAddLocalMessage()

  onSaveSessionInfo()

  onCreateCover()

  onCreateNewWindow()

  onSaveAs()

  onSaveClipBoardFile()

  onGetLocalUser()

  onReLogin(() => {
    mainWindow.setResizable(true)
    mainWindow.setMinimumSize(login_width, login_height)
    mainWindow.setSize(login_width, login_height)
    mainWindow.center()
    mainWindow.setResizable(false)
  })

  onLoadContactApply()

  onUpdateContactNoReadCount()

  onReLoadChatSession()

  onChatMessageFileDetail()

  onChangeFolder()

  onOpenLocalFolder()

  onGetSyssetting()

  onOpenUrl()

  onDownloadUpdate()
}

app.whenReady().then(() => {
  electronApp.setAppUserModelId('com.electron')

  app.on('browser-window-created', (_, window) => {
    optimizer.watchWindowShortcuts(window)
  })
  createWindow()

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})
