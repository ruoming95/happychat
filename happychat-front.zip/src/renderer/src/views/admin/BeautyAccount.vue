<template>
  <div>
    <div class="top-panel">
      <el-form :model="searchForm" ref="formDataRef" label-width="70px">
        <el-row>
          <el-col :span="8">
            <el-form-item label="靓号" label-width="40px">
              <el-input
                class="password-input"
                v-model="searchForm.userIdFuzzy"
                clearable
                placeholder="支持模糊搜索"
                @keyup.native="loadDataList"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8" :offset="1">
            <el-form-item label="邮箱">
              <el-input
                class="password-input"
                v-model="searchForm.emailFuzzy"
                clearable
                placeholder="支持模糊搜索"
                @keyup.native="loadDataList"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4" :style="{ paddingLeft: '10px' }">
            <el-button type="success" @click="loadDataList()">查询</el-button>
            <el-button type="primary" @click="editAccount()">新增靓号</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <Table :columns="columns" :fetch="loadDataList" :dataSource="tableData" :options="tableOptions">
      <template #slotAvatar="{ index, row }">
        <AvatarBase :width="50" :userId="row.userId" partType="avatar"></AvatarBase>
      </template>

      <template #slotNickName="{ index, row }">
        {{ row.nickName }}
        {{ row.userId }}
        <span v-if="row.sex == 0" class="iconfont icon-woman"></span>
        <span v-if="row.sex == 1" class="iconfont icon-man"></span>
      </template>

      <template #slotStatus="{ index, row }">
        <span style="color: red" v-if="!row.status || row.status == 0">未使用</span>
        <span style="color: #07c160" v-else>已使用</span>
      </template>

      <template #slotOnline="{ index, row }">
        <span style="color: red" v-if="row.onlineType == 0">离线</span>
        <span style="color: #07c160" v-else>在线</span>
      </template>

      <template #slotOperation="{ index, row }">
        <el-dropdown placement="bottom-end" trigger="click" v-if="userInfo.userId != row.userId">
          <span class="iconfont icon-more"></span>
          <template #dropdown>
            <el-dropdown-item @click="editAccount(row)" v-if="row.status == 0">
              修改
            </el-dropdown-item>
            <el-dropdown-item @click="delAccount(row)" v-else> 删除</el-dropdown-item>
          </template>
        </el-dropdown>
        <div v-else>管理员</div>
      </template>
    </Table>
  </div>
  <BeautyAccountEdit ref="beautyAccountEditRef" @reload="loadDataList"></BeautyAccountEdit>
</template>

<script setup>
import { ref, reactive, getCurrentInstance, nextTick, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import BeautyAccountEdit from './BeautyAccountEdit.vue'
import { useUserInfoStore } from '@/stores/UserInfoStore'
const userInfoStore = useUserInfoStore()
const userInfo = userInfoStore.getUserInfo()
const { proxy } = getCurrentInstance()
const route = useRoute()
const router = useRouter()

const tableData = ref([])
const tableOptions = ref()
const columns = [
  {
    label: '邮箱',
    prop: 'email'
  },
  {
    label: '靓号',
    prop: 'userId'
  },
  {
    label: '状态',
    prop: 'status',
    width: 70,
    scopedSlots: 'slotStatus'
  },
  {
    label: '操作',
    prop: 'operation',
    scopedSlots: 'slotOperation'
  }
]

const searchForm = ref({})

const loadDataList = async () => {
  let params = {
    pageNo: tableData.value.pageNo,
    pageSize: tableData.value.pageSize
  }
  Object.assign(params, searchForm.value)
  let result = await proxy.Request({
    url: proxy.Api.loadBeautyAccount,
    params: params
  })
  if (!result) {
    return
  }
  Object.assign(tableData.value, result.data)
}
const beautyAccountEditRef = ref({})
const editAccount = (data) => {
  beautyAccountEditRef.value.showEdit(data)
}

const delAccount = (data) => {
  proxy.Confirm({
    message: `你确定要删除【${data.email}】对应的账号吗？`,
    okfun: async () => {
      let result = await proxy.Request({
        url: proxy.Api.delBeautyAccount,
        params: {
          id: data.id
        }
      })
      if (!result) {
        return
      }
      proxy.Message.success('删除成功')
      loadDataList()
    }
  })
}

onMounted(() => {
  loadDataList()
})
</script>

<style lang="scss" scoped></style>
