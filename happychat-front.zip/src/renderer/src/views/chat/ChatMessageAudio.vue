<template>
  <div class="audio-show">
    <div class="text">
      <div class="audio-show-name">{{ data.fileName }}</div>
      <div class="audio-show-size">{{ proxy.Utils.formatFileSize(data.fileSize) }}</div>
      <div class="audio-show-icon">
        <img src="../../assets/img/yinle.png" alt="" />
      </div>
    </div>
    <AudioPlay
      class="audio-play"
      :fileId="data.messageId"
      partType="chat"
      :fileType="data.fileType"
      @showLoading="showLoading"
    ></AudioPlay>
  </div>
</template>

<script setup>
import { ref, reactive, getCurrentInstance, nextTick } from 'vue'
import AudioPlay from '../../components/AudioPlay.vue'
const { proxy } = getCurrentInstance()
const loading = ref(true)
const showLoading = (data) => {
  loading.value = data
}
const props = defineProps({
  data: {
    type: Object,
    default: {}
  },
  currentSessionId: {
    type: Object,
    default: {}
  }
})
</script>

<style lang="scss" scoped>
.audio-show {
  display: flex;
  position: relative;
  width: 270px;
  height: 120px;
  background-color: #ebebeb;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  .text {
    position: absolute;
    left: 10px;
    top: 0px;
    .audio-show-name {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      padding: 8px 10px;
      font-size: 14px;
      font-weight: bolder;
      max-width: 150px;
    }
    .audio-show-size {
      padding: 0px 10px;
      font-size: 12px;
      color: #999999;
    }
  }
  .audio-play {
    position: absolute;
    top: 80px;
  }
  .audio-show-icon {
    position: absolute;
    right: -100px;
    top: 10px;
    width: 70px;
    height: 60px;
    overflow: hidden;
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
}
</style>
