<template>
  <Layout>
    <template #left-content>
      <div class="drag-panel drag"></div>
      <div class="top-search">
        <el-input clearable placeholder="搜索" v-model="searchKey" size="small" @keyup="search">
          <template #suffix> <span class="iconfont icon-search"></span> </template
        ></el-input>
      </div>
      <div class="chat-session-list" v-if="!searchKey">
        <template v-for="item in chatSessionList">
          <ChatSession
            :data="item"
            @click="chatSessionClickHandler(item)"
            @contextmenu.stop="onContextMenu(item, $event)"
            :currentSession="item.contactId == currentChatSession.contactId"
          >
          </ChatSession>
        </template>
      </div>
      <div class="search-list" v-show="searchKey">
        <SearchResult
          :data="item"
          v-for="item in searchList"
          @click="searchClickHandler(item)"
        ></SearchResult>
      </div>
    </template>
    <template #right-content>
      <div class="title-panel drag" v-if="Object.keys(currentChatSession).length > 0">
        <div class="title">
          <span>{{ currentChatSession.contactName }}</span>
          <span v-if="currentChatSession.contactType == 1">
            ({{ currentChatSession.memberCount }})</span
          >
        </div>
      </div>
      <div
        v-if="currentChatSession.contactType == 1"
        class="iconfont icon-more no-drag"
        @click="showGroupDetail"
      ></div>
      <div class="chat-panel" v-show="Object.keys(currentChatSession).length > 0">
        <div class="message-panel" id="message-panel">
          <div
            class="message-item"
            v-for="(data, index) in messageList"
            :id="'message' + data.messageId"
          >
            <!-- 显示时间 -->
            <template
              v-if="
                (index > 1 &&
                  data.sendTime - messageList[index - 1].sendTime >= 300000 &&
                  data.messageType == 2) ||
                data.messageType == 5
              "
            >
              <ChatMessageTime :data="data"></ChatMessageTime>
            </template>

            <!-- 系统消息 
             1:添加好友成功
             3:群创建成功
             8:解散群聊
             9:好友加入群组
             11:退出群聊
             12:踢出群聊-->
            <template
              v-if="
                data.messageType == 1 ||
                data.messageType == 3 ||
                data.messageType == 8 ||
                data.messageType == 9 ||
                data.messageType == 11 ||
                data.messageType == 12 ||
                data.messageType == 13
              "
            >
              <ChatMessageSys :data="data"></ChatMessageSys>
            </template>

            <template
              v-if="data.messageType == 1 || data.messageType == 2 || data.messageType == 5"
            >
              <ChatMessage
                :data="data"
                :currentChatSession="currentChatSession"
                @showDetail="showDetailHandler"
              ></ChatMessage>
            </template>
          </div>
        </div>
        <MessageSend
          :currentChatSession="currentChatSession"
          @addSendMessageToLocal="addSendMessageToLocal"
        ></MessageSend>
      </div>
      <div class="chat-blank" v-show="Object.keys(currentChatSession).length == 0">
        <Blank></Blank>
      </div>
    </template>
  </Layout>
  <ChatGroupDetail
    ref="chatGroupDetailRef"
    @delChatSessionCallback="delChatSession"
  ></ChatGroupDetail>
  <AudioPlay ref="audioPlayRef" :showPlay="false"></AudioPlay>
</template>

<script setup>
import { ref, reactive, getCurrentInstance, nextTick, onMounted, onUnmounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import AudioPlay from '../../components/AudioPlay.vue'
import ChatSession from './ChatSession.vue'
import ChatMessage from './ChatMessage.vue'
import MessageSend from './MessageSend.vue'
import ChatMessageTime from './ChatMessageTime.vue'
import ChatMessageSys from './ChatMessageSys.vue'
import ChatGroupDetail from './ChatGroupDetail.vue'
import SearchResult from './SearchResult.vue'
import Blank from '@/components/Blank.vue'
import ContextMenu from '@imengyu/vue3-context-menu'
import '@imengyu/vue3-context-menu/lib/vue3-context-menu.css'
import { useMessageCountStore } from '@/stores/MessageCountStore'
const messageCountStore = useMessageCountStore()
const route = useRoute()
const router = useRouter()

const { proxy } = getCurrentInstance()
const chatSessionList = ref([])
const currentChatSession = ref({})
const searchKey = ref()
const audioPlayRef = ref()
const searchList = ref([])
const search = () => {
  if (!searchKey.value) {
    return
  }
  searchList.value = []
  const regex = new RegExp('(' + searchKey.value + ')', 'gi')
  chatSessionList.value.forEach((item) => {
    if (item.contactName.includes(searchKey.value) || item.lastMessage.includes(searchKey.value)) {
      let newData = Object.assign({}, item)
      newData.searchContactName = newData.contactName.replace(
        regex,
        "<span class='highlight'>$1</span>"
      )
      newData.searchLastMessage = newData.lastMessage.replace(
        regex,
        "<span class='highlight'>$1</span>"
      )
      searchList.value.push(newData)
    }
  })
}

const searchClickHandler = (item) => {
  chatSessionClickHandler(item)
  searchKey.value = undefined
}

const messageCountInfo = {
  totalPage: 0,
  pageNo: 0,
  maxMessageId: null,
  noData: false
}
const messageList = ref([])
let distanceBottom = 0

//从本地加载消息
const loadChatMessage = () => {
  if (messageCountInfo.noData) {
    return
  }
  messageCountInfo.pageNo++
  window.ipcRenderer.send('loadChatMessage', {
    sessionId: currentChatSession.value.sessionId,
    pageNo: messageCountInfo.pageNo,
    maxMessageId: messageCountInfo.maxMessageId
  })
}

const onLoadChatMessage = () => {
  window.ipcRenderer.on('loadChatMessageCallback', (e, { dataList, pageTotal, pageNo }) => {
    if (pageNo == pageTotal) {
      messageCountInfo.noData = true
    }
    dataList.sort((a, b) => {
      return a.sendTime - b.sendTime
    })
    console.log('加载本地消息', dataList)
    const lastMessage = messageList.value[0]
    messageList.value = dataList.concat(messageList.value)
    messageCountInfo.pageNo = pageNo
    messageCountInfo.pageTotal = pageTotal
    if (pageNo == 1) {
      messageCountInfo.maxMessageId =
        dataList.length > 0 ? dataList[dataList.length - 1].messageId : null

      //滚动条滚动到最底部
      gotoBottom()
    } else {
      nextTick(() => {
        document.querySelector('#message' + lastMessage.messageId).scrollIntoView()
      })
    }
  })
}

const onReceiveMessage = () => {
  ipcRenderer.on('receiveMessage', (e, message) => {
    console.log('收到服务器消息', message)
    if (message.messageType == 0) {
      loadSessionData()
      return
    }
    let curSession = chatSessionList.value.find((item) => {
      return item.sessionId == message.sessionId
    })
    if (
      route.path != '/chat' ||
      (curSession == null &&
        (message.messageType == '1' ||
          message.messageType == '2' ||
          message.messageType == '3' ||
          message.messageType == '5'))
    ) {
      if (audioPlayRef.value) {
        audioPlayRef.value.play()
      }
    }

    if (message.messageType == 4) {
      loadContactApply()
      return
    }
    if (message.messageType == 6) {
      const localMessage = messageList.value.find((item) => {
        if (item.messageId == message.messageId) {
          return item
        }
      })
      if (localMessage != null) {
        localMessage.status = 1
      }
      return
    }
    //强制下线
    if (message.messageType == 7) {
      proxy.Confirm({
        message: `你已被管理员强制下线？`,
        okfun: () => {
          setTimeout(() => {
            window.ipcRenderer.send('reLogin')
          }, 200)
        },
        showCancelBtn: false
      })
      return
    }
    // 更改群昵称
    if (message.messageType == 10 && curSession != null) {
      curSession.contactName = message.extendData
      return
    }
    if (curSession == null) {
      chatSessionList.value.push(message.extendData)
      console.log('curSession空', chatSessionList.value)
    } else {
      Object.assign(curSession, message.extendData)
    }
    sortChatSessionList(chatSessionList.value)
    if (message.sessionId != currentChatSession.value.sessionId) {
      messageCountStore.setCount('chatCount', 1, false)
      if (audioPlayRef.value) {
        audioPlayRef.value.play()
      }
    } else {
      Object.assign(currentChatSession.value, message.extendData)
      messageList.value.push(message)
      gotoBottom()
    }
  })
}

const loadContactApply = () => {
  window.ipcRenderer.send('loadContactApply')
}
const onLoadContactApply = () => {
  window.ipcRenderer.on('loadContactApplyCallback', (e, contactNoRead) => {
    console.log('未读申请数', contactNoRead)
    messageCountStore.setCount('contactApplyCount', contactNoRead, true)
  })
}

const onLoadSessionData = () => {
  window.ipcRenderer.on('loadSessionDataCallback', (e, dataList) => {
    console.log('从本地加载会话数据', dataList)
    sortChatSessionList(dataList)
    chatSessionList.value = dataList
    console.log('chatSessionList', chatSessionList.value)
    let noReadCount = 0
    dataList.forEach((element) => {
      noReadCount = element.noReadCount + noReadCount
    })
    messageCountStore.setCount('chatCount', noReadCount, true)
  })
}

const onAddLocalMessage = () => {
  window.ipcRenderer.on('addLocalMessageCallback', (e, { messageId, status }) => {
    const findMessage = messageList.value.find((item) => {
      return item.messageId === messageId ? item : null
    })
    if (findMessage != null) {
      findMessage.status = status
    }
  })
}

const loadSessionData = () => {
  window.ipcRenderer.send('loadSessionData')
}

const setTop = (data) => {
  data.topType = data.topType == 0 ? 1 : 0
  sortChatSessionList(chatSessionList.value)
  window.ipcRenderer.send('topChatSession', { contactId: data.contactId, topType: data.topType })
}

const delChatSession = (contactId) => {
  delChatSessionList(contactId)
  currentChatSession.value = {}
  saveSessionInfo({})
  window.ipcRenderer.send('delChatSession', contactId)
}

const onContextMenu = (data, e) => {
  ContextMenu.showContextMenu({
    x: e.x,
    y: e.y,
    items: [
      {
        label: data.topType == 0 ? '置顶' : '取消置顶',
        onClick: () => {
          setTop(data)
        }
      },
      {
        label: '删除聊天',
        onClick: () => {
          proxy.Confirm({
            message: `确定要删除聊天【${data.contactName}】吗?`,
            okfun: () => {
              delChatSession(data.contactId)
            }
          })
        }
      }
    ]
  })
}

const delChatSessionList = (contactId) => {
  setTimeout(() => {
    chatSessionList.value = chatSessionList.value.filter((item) => {
      return item.contactId !== contactId
    })
  }, 100)
}

const sortChatSessionList = (dataList) => {
  dataList.sort((a, b) => {
    const topTypeResult = b['topType'] - a['topType']
    if (topTypeResult == 0) {
      return b['lastReceiveTime'] - a['lastReceiveTime']
    }
    return topTypeResult
  })
}

const addSendMessageToLocal = (messageObj) => {
  messageList.value.push(messageObj)
  const chatSession = chatSessionList.value.find((item) => {
    return item.sessionId == messageObj.sessionId
  })
  if (chatSession) {
    chatSession.lastReceiveTime = messageObj.sendTime
    ChatSession.lastMessage = messageObj.lastMessage
  }
  sortChatSessionList(chatSessionList.value)
  gotoBottom()
}

//滚动到底部
const gotoBottom = () => {
  nextTick(() => {
    if (distanceBottom > 200) {
      return
    }
    const element = document.querySelectorAll('.message-item')
    if (element.length > 0) {
      setTimeout(() => {
        element[element.length - 1].scrollIntoView()
      }, 10)
    }
  })
}

const showDetailHandler = (messageId) => {
  let showFileList = messageList.value.filter((item) => {
    //媒体消息
    return item.messageType == 5
  })
  showFileList = showFileList.map((item) => {
    return {
      partType: 'chat',
      fileId: item.messageId,
      fileType: item.fileType,
      fileName: item.fileName,
      fileSize: item.fileSize,
      forceGet: false
    }
  })

  let titleType = {
    '0': '图片查看',
    '1': '视频播放',
    '2': '文件预览'
  }

  let currentFileType = messageList.value.find((item) => {
    if (messageId == item.messageId) {
      return item
    }
  })

  currentFileType = currentFileType.fileType
  if (currentFileType == 2 || currentFileType == 3) {
    return
  }

  window.ipcRenderer.send('createNewWindow', {
    windowId: 'media',
    title: titleType[currentFileType],
    path: '/showMedia',
    data: {
      currentFileId: messageId,
      fileList: showFileList
    }
  })
}

const chatGroupDetailRef = ref()
const showGroupDetail = () => {
  chatGroupDetailRef.value.show(currentChatSession.value.contactId)
}

const chatSessionClickHandler = (item) => {
  distanceBottom = 0
  currentChatSession.value = Object.assign({}, item)
  messageCountStore.setCount('chatCount', -item.noReadCount, false)
  item.noReadCount = 0
  messageCountInfo.pageNo = 0
  messageCountInfo.pageTotal = 1
  messageCountInfo.maxMessageId = null
  messageCountInfo.noData = false
  messageList.value = []
  loadChatMessage()
  console.log(item)

  //让主进程记录选中会话信息
  saveSessionInfo({ contactId: item.contactId, sessionId: item.sessionId })
}

const saveSessionInfo = ({ contactId, sessionId }) => {
  window.ipcRenderer.send('saveSessionInfo', { contactId, sessionId })
}

const sendMessage = (contactId) => {
  let curSession = chatSessionList.value.find((item) => {
    return item.contactId == contactId
  })
  //会话不存在， 从本地重新加载
  if (!curSession) {
    window.ipcRenderer.send('reLoadChatSession', contactId)
    return
  } else {
    console.log(curSession)
    chatSessionClickHandler(curSession)
  }
}

watch(
  () => route.path,
  (newVal, oldVal) => {
    saveSessionInfo({})
    currentChatSession.value = {}
  },
  { immediate: true, deep: true }
)

watch(
  () => route.query.timestamp,
  (newVal, oldVal) => {
    if (newVal && route.query.chatId) {
      console.log('query', route.query.chatId)
      sendMessage(route.query.chatId)
    }
  },
  { immediate: true, deep: true }
)

const onReloadChatSession = () => {
  window.ipcRenderer.on('reLoadChatSessionCallback', (e, { contactId, chatSessionList }) => {
    sortChatSessionList(chatSessionList)
    chatSessionList.value = chatSessionList
    sendMessage(contactId)
  })
}

onMounted(() => {
  loadSessionData()

  onLoadSessionData()

  onLoadChatMessage()

  onAddLocalMessage()

  onReceiveMessage()

  onLoadContactApply()

  nextTick(() => {
    const messagePanel = document.querySelector('#message-panel')
    messagePanel.addEventListener('scroll', (e) => {
      distanceBottom = e.target.scrollHeight - e.target.clientHeight - e.target.scrollTop
      if (e.target.scrollTop == 0 && messageList.value.length > 0) {
        loadChatMessage()
      }
    })
  })

  saveSessionInfo({})

  onReloadChatSession()
})

onUnmounted(() => {
  window.ipcRenderer.removeAllListeners('loadSessionDataCallback')
  window.ipcRenderer.removeAllListeners('loadSessionData')
  window.ipcRenderer.removeAllListeners('loadChatMessage')
  window.ipcRenderer.removeAllListeners('addLocalMessageCallback')
  window.ipcRenderer.removeAllListeners('reLoadChatSessionCallback')
  window.ipcRenderer.removeAllListeners('receiveMessage')
  saveSessionInfo({})
})
</script>

<style lang="scss" scoped>
.drag-panel {
  height: 25px;
  background-color: #f7f7f7;
}

.top-search {
  padding: 0px 10px 9px 10px;
  background-color: #f7f7f7;
  display: flex;
  align-items: center;
  .iconfont {
    font-size: 12px;
  }
}

.chat-session-list {
  height: calc(100vh - 62px);
  overflow: hidden;
  border-top: 1px solid #ddd;
  &:hover {
    overflow: auto;
  }
}

.search-list {
  height: calc(100vh - 62px);
  background-color: #f7f7f7;
  overflow: hidden;
  &:hover {
    overflow: auto;
  }
}

.title-panel {
  display: flex;
  align-items: center;
  .title {
    height: 60px;
    line-height: 60px;
    padding-left: 10px;
    font-size: 18px;
    color: #000;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}

.icon-more {
  position: absolute;
  top: 30px;
  right: 3px;
  width: 20px;
  font-size: 20px;
  margin-right: 5px;
  cursor: pointer;
  &:hover {
    cursor: pointer;
    background-color: #ddd;
  }
}

.chat-panel {
  border-top: 1pt solid #ddd;
  background-color: #f5f5f5;
  .message-panel {
    padding: 10px 30px 0px 30px;
    height: calc(100vh - 200px - 62px);
    overflow-y: auto;
    .message-item {
      margin-bottom: 15px;
      text-align: center;
    }
  }
}
</style>
