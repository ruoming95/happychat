<template>
  <div class="media-window">
    <div class="win-title drag"></div>
    <div class="media-op no-drag">
      <div
        :class="['iconfont icon-left', currentIndex == 0 ? 'not-allow' : '']"
        @dblclick.stop
        title="上一张"
        @click="next(-1)"
      ></div>
      <div
        :class="['iconfont icon-right', currentIndex >= allFileList.length - 1 ? 'not-allow' : '']"
        @dblclick.stop
        title="下一张"
        @click="next(1)"
      ></div>
      <template v-if="fileList[0].fileType == 0">
        <el-divider direction="vertical" />
        <div
          :class="['iconfont icon-enlarge']"
          @dblclick.stop
          title="放大"
          @click="changeSize(0.1)"
        ></div>
        <div
          :class="['iconfont icon-narrow']"
          @dblclick.stop
          title="缩小"
          @click="changeSize(-0.1)"
        ></div>
        <div
          :class="['iconfont', isOneToOne ? 'icon-resize' : 'icon-source-size']"
          @dblclick.stop
          :title="isOneToOne ? '图片适应窗口大小' : '图片原始大小'"
          @click="resize"
        ></div>
        <div :class="['iconfont icon-rotate']" @dblclick.stop title="旋转" @click="rotate"></div>
        <el-divider direction="vertical" />
      </template>
      <div :class="['iconfont icon-download']" @dblclick.stop title="下载" @click="saveAs"></div>
    </div>
    <div class="media-panel">
      <viewer
        :options="options"
        :images="fileList"
        @inited="inited"
        v-if="fileList[0].fileType == 0 && fileList[0].status == 1"
      >
        <img :src="fileList[0].url" />
      </viewer>
      <div
        ref="player"
        id="player"
        v-show="fileList[0].fileType == 1 && fileList[0].status == 1"
        style="width: 100%; height: 100%"
      ></div>
      <div v-if="fileList[0].fileType == 2 && fileList[0].status == 1">文件</div>
      <div class="loading" v-if="fileList[0].status != 1">加载中...</div>
    </div>
    <WinOp @closeCallback="closeWin"></WinOp>
  </div>
</template>

<script setup>
import { ref, getCurrentInstance, onMounted, onUnmounted } from 'vue'
import DPlayer from 'dplayer'
import { component as Viewer } from 'v-viewer'
import 'viewerjs/dist/viewer.css'
const { proxy } = getCurrentInstance()

const currentIndex = ref(0)
const allFileList = ref([])

const viewerRef = ref(null)
const options = ref({
  inline: true,
  toolbar: false,
  navbar: false,
  button: false,
  title: false,
  zoomRatio: 0.1,
  zoomOnWheel: false
})

const inited = (e) => {
  viewerRef.value = e
}

const changeSize = (zoomRatio) => {
  if (!viewerRef.value) {
    return
  }
  viewerRef.value.zoom(zoomRatio, true)
}

const rotate = () => {
  viewerRef.value.rotate(90, true)
}

const isOneToOne = ref(false)
const resize = () => {
  isOneToOne.value = !isOneToOne.value
  if (!isOneToOne) {
    viewerRef.value.zoomTo(viewerRef.value.initialImageData.radio, true)
  } else {
    viewerRef.value.zoomTo(1, true)
  }
}

const next = (index) => {
  if (currentIndex.value + index < 0 || currentIndex.value + index >= allFileList.value.length) {
    return
  }
  currentIndex.value = currentIndex.value + index
  getCurrentFile()
}

const saveAs = () => {
  const curFile = allFileList.value[currentIndex.value]
  window.ipcRenderer.send('saveAs', {
    partType: curFile.partType,
    fileId: curFile.fileId
  })
}

const onSaveAsCallback = () => {
  ipcRenderer.on('saveAsCallback', () => {
    proxy.Message.success('保存成功')
  })
}

const onWheel = (e) => {
  if (fileList.value[0].fileType !== 0) {
    return
  }
  if (e.deltaY < 0) {
    changeSize(0.1)
  } else {
    changeSize(-0.1)
  }
}

const player = ref()
const dPlayer = ref()
const initPlayer = () => {
  dPlayer.value = new DPlayer({
    container: document.getElementById('player'),
    element: player.value,
    theme: '#007BFF',
    screenshot: true,
    volume: 0.5,
    autoplay: true,
    muted: true,
    playbackSpeed: [0.5, 0.75, 1, 1.25, 1.5, 2],
    video: {
      url: ''
    }
  })
}

const fileList = ref([{ fileType: 0, status: 0 }])
const localServerPort = ref()

const closeWin = () => {
  dPlayer.value.pause()
}

const getCurrentFile = () => {
  if (dPlayer.value) {
    dPlayer.value.pause()
  }
  const curFile = allFileList.value[currentIndex.value]
  const url = getUrl(curFile)
  fileList.value.splice(0, 1, {
    url: url,
    fileSize: curFile.fileSize,
    fileType: curFile.fileType,
    fileName: curFile.fileName,
    status: 1
  })

  if (curFile.fileType == 1) {
    dPlayer.value.switchVideo({
      url: url
    })
  }
}

const getUrl = (curFile) => {
  return `http://127.0.0.1:${localServerPort.value}/file?fileId=${curFile.fileId}&partType=${curFile.partType}&fileType=${curFile.fileType}&forceGet=${curFile.forceGet}&${new Date().getTime()}`
}

onMounted(() => {
  initPlayer()

  onSaveAsCallback()

  window.addEventListener('wheel', onWheel)

  window.ipcRenderer.on('pageInitData', (e, data) => {
    //获取改聊天消息的所有文件
    allFileList.value = data.fileList
    // console.log(data)

    let index = 0

    if (data.currentFileId) {
      index = data.fileList.findIndex((item) => item.fileId == data.currentFileId)

      index = index == -1 ? 0 : index
    }
    currentIndex.value = index

    localServerPort.value = data.localServerPort
    getCurrentFile()
  })
})

onUnmounted(() => {
  window.removeAllListeners('wheel', onWheel)
  window.removeAllListeners('pageInitData', () => {})
  window.removeAllListeners('saveAsCallback')
})
</script>

<style lang="scss" scoped>
img {
  display: none;
}
.media-window {
  padding: 0px;
  height: calc(100vh);
  border: 1px solid #ddd;
  background-color: #fff;
  position: relative;
  overflow: hidden;
  .win-title {
    height: 37px;
  }
  .media-op {
    position: absolute;
    left: 0px;
    top: 0px;
    height: 35px;
    display: flex;
    align-items: center;
    line-height: 35px;
    .iconfont {
      font-size: 18px;
      padding: 0px 10px;
      &:hover {
        background-color: #f3f3f3;
        cursor: pointer;
      }
    }
    .not-allow {
      cursor: not-allowed;
      color: #ddd;
      text-decoration: none;
      &:hover {
        color: #ddd;
        cursor: not-allowed;
        background-color: none;
      }
    }
  }
  .media-panel {
    display: flex;
    justify-content: center;
    align-items: center;
    height: calc(100vh - 37px);
    overflow: hidden;
    :deep(.viewer-backdrop) {
      background-color: #f5f5f5;
    }

    .file-panel {
      .file-item {
        margin-top: 5px;
      }
      .download {
        margin-top: 20px;
        text-align: center;
      }
    }
  }
}
</style>
