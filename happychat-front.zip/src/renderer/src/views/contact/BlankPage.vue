<template>
  <Blank></Blank>
</template>

<script setup>
import Blank from '../../components/Blank.vue'
</script>

<style lang="scss" scoped></style>
