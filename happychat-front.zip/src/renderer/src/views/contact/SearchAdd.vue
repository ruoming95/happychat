<template>
  <div>
    <Dialog
      :show="dialogConfig.show"
      :title="dialogConfig.title"
      :buttons="dialogConfig.buttons"
      width="400px"
      :showCancel="false"
      @close="dialogConfig.show = false"
    >
      <el-form :model="formData" :rules="rules" ref="formDataRef" @submit.prevent>
        <!--input输入-->
        <el-form-item label="" prop="">
          <el-input
            clearable
            placeholder="输入申请信息"
            type="textarea"
            :rows="5"
            resize="none"
            v-model.trim="formData.applyInfo"
            :show-word-limit="true"
            :maxlength="100"
          ></el-input>
        </el-form-item>
        <!--textarea输入-->
      </el-form>
    </Dialog>
  </div>
</template>

<script setup>
import { ref, reactive, getCurrentInstance, nextTick } from 'vue'
import { useUserInfoStore } from '@/stores/UserInfoStore'

const userInfoStore = useUserInfoStore()
const { proxy } = getCurrentInstance()

const formData = ref({})
const formDataRef = ref()

const rules = {
  title: [{ require: true, message: '请输入内容' }]
}
const dialogConfig = ref({
  show: false,
  title: '提交申请',
  buttons: [
    {
      types: 'primary',
      text: '确定',
      click: (e) => {
        submitApply()
      }
    }
  ]
})

const emit = defineEmits(['reload'])
const submitApply = async () => {
  const { contactId, contactType, applyInfo } = formData.value
  //发送请求
  let result = await proxy.Request({
    url: proxy.Api.applyAdd,
    params: {
      contactId: contactId,
      contactType: contactType,
      applyInfo: applyInfo
    }
  })
  if (!result) {
    return
  }

  proxy.Message.success('申请成功，等待审核')
  dialogConfig.value.show = false
  emit('reload')
}

const show = (data) => {
  dialogConfig.value.show = true
  nextTick(() => {
    formDataRef.value.resetFields()
    formData.value = Object.assign({}, data)
    formData.value.applyInfo = '我是' + userInfoStore.getUserInfo().nickName
  })
}

defineExpose({
  show
})
</script>

<style lang="scss" scoped></style>
