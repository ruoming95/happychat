<template>
  <div class="search-item">
    <Avatar :userId="data.contactId" :showDetail="false"></Avatar>
    <div class="contact-info">
      <div class="contact-name" v-html="data.searchContactName"></div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, getCurrentInstance, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
const { proxy } = getCurrentInstance()
const route = useRoute()
const router = useRouter()

const props = defineProps({
  data: {
    type: Object,
    default: {}
  }
})
</script>

<style lang="scss" scoped>
.search-item {
  padding: 10px;
  display: flex;
  align-items: center;
  .contact-info {
    margin-left: 10px;
    :deep(.highlight) {
      color: #36c0f4;
    }
  }

  &:hover {
    background-color: #ededed;
  }
}
</style>
