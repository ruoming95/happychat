<template>
  <ContentPanel><GroupForm></GroupForm> </ContentPanel>
</template>

<script setup>
import { ref, reactive, getCurrentInstance, nextTick } from 'vue'
import GroupForm from './GroupForm.vue'
import ContentPanel from '@/components/ContentPanel.vue'
const { proxy } = getCurrentInstance()
</script>

<style lang="scss" scoped></style>
