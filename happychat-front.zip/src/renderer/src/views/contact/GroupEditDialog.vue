<template>
  <Dialog
    :show="dialogConfig.show"
    :title="dialogConfig.title"
    :buttons="dialogConfig.buttons"
    width="400px"
    :showCancel="false"
    @close="dialogConfig.show = false"
  >
    <GroupForm ref="groupFormRef" @editBack="editBack"></GroupForm>
  </Dialog>
</template>

<script setup>
import { ref, reactive, getCurrentInstance, nextTick } from 'vue'
import GroupForm from './GroupForm.vue'
import { useRoute, useRouter } from 'vue-router'
const { proxy } = getCurrentInstance()
const route = useRoute()
const router = useRouter()

const dialogConfig = ref({
  show: false,
  title: '修改群组',
  buttons: []
})

const groupFormRef = ref()
const show = (data) => {
  dialogConfig.value.show = true
  nextTick(() => {
    groupFormRef.value.show(data)
  })
}

const emit = defineEmits(['reloadGroupInfo'])
const editBack = () => {
  dialogConfig.value.show = false
  emit('reloadGroupInfo')
}

defineExpose({
  show
})
</script>

<style lang="scss" scoped></style>
