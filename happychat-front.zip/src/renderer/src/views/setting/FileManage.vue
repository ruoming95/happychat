<template>
  <ContentPanel v-loading="copying" element-loading-text="正在复制文件">
    <el-form
      label-position="top"
      :model="formData"
      :rules="rules"
      ref="formDataRef"
      label-width="80px"
      @submit.prevent
    >
      <!-- 输入输入 -->
      <el-form-item label="文件管理" prop="" class="file-manage">
        <div class="file-input" :title="formData.sysSetting">{{ formData.sysSetting }}</div>
        <div class="tips">文件默认保存位置</div>
      </el-form-item>
      <el-form-item label="" prop="">
        <el-button type="primary" @click="changeFolder">更改</el-button>
        <el-button type="primary" @click="openLocalFolder">打开文件夫</el-button>
      </el-form-item>
    </el-form>
  </ContentPanel>
</template>
<script setup>
import { ref, reactive, getCurrentInstance, nextTick, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
const { proxy } = getCurrentInstance()
const route = useRoute()
const router = useRouter()

const copying = ref(false)

const formData = ref({})
const formDataRef = ref()
const rules = {}

const getSyssetting = () => {
  window.ipcRenderer.send('getSyssetting')
}

const onCopyingCallback = () => {
  window.ipcRenderer.on('copyingCallback', () => {
    copying.value = true
  })
}

const changeFolder = () => {
  window.ipcRenderer.send('changeFolder')
}

const openLocalFolder = () => {
  window.ipcRenderer.send('openLocalFolder')
}

onMounted(() => {
  window.ipcRenderer.on('getSyssettingCallback', (e, sysSetting) => {
    copying.value = false
    sysSetting = JSON.parse(sysSetting)
    formData.value = {
      sysSetting: sysSetting.localFileFolder
    }
    console.log(formData.value)
  })
  getSyssetting()

  onCopyingCallback()
})

onUnmounted(() => {
  window.ipcRenderer.removeAllListeners('getSyssettingCallback')
})
</script>

<style lang="scss" scoped>
.file-manage {
  :deep(.el-form-item__content) {
    display: block;
  }

  .file-input {
    background: #fff;
    padding: 0px 5px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 16px;
  }

  .tips {
    color: #888888;
    font-size: 13px;
  }
}
</style>
