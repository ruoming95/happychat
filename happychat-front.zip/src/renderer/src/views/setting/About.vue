<template>
  <ContentPanel>
    <el-form :rules="rules" ref="formDataRef" label-width="80px" @submit.prevent>
      <!-- 输入输入 -->
      <el-form-item label="版本信息">
        <div class="version-info">
          <div>开心交友{{ config.version }}</div>
          <div>
            <el-button type="primary" @click="checkUpdate">检查更新</el-button>
          </div>
        </div>
      </el-form-item>
    </el-form>
  </ContentPanel>
  <Update :autoUpdate="false" ref="updateRef"></Update>
</template>

<script setup>
import Update from '../Update.vue'
import config from '../../../../../package.json'
import { ref, reactive, getCurrentInstance, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
const { proxy } = getCurrentInstance()
const route = useRoute()
const router = useRouter()

const updateRef = ref()
const checkUpdate = () => {
  updateRef.value.checkUpdate()
}
</script>

<style lang="scss" scoped></style>
