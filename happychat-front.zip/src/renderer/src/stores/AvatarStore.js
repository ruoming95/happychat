import { defineStore } from 'pinia'
export const useAvatarStore = defineStore({
  id: 'avatarStore',

  state: () => {
    return {
      avatarMap: {}
    }
  },
  actions: {
    setAvatarStore(key, value) {
      this.avatarMap[key] = value
    },

    getAvatarStore(key) {
      return this.avatarMap[key]
    }
  }
})
