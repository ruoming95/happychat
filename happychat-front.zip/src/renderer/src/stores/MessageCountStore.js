import { defineStore } from 'pinia'
export const useMessageCountStore = defineStore({
  id: 'messageCount',

  state: () => {
    return {
      messageCount: {
        chatCount: 0,
        contactApplyCount: 0
      }
    }
  },
  actions: {
    setCount(key, value, forceUpdate) {
      if (forceUpdate) {
        this.messageCount[key] = value
        return
      }
      let count = this.messageCount[key]
      this.messageCount[key] = value + count
      console.log(key + ':', this.messageCount[key])
    },

    getCount(key) {
      return this.messageCount[key]
    }
  }
})
