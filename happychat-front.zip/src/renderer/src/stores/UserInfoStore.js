// useUserStore.js
import { defineStore } from 'pinia'

export const useUserInfoStore = defineStore({
  // 唯一标识符，用于区分不同的 store
  id: 'userInfo',

  // 状态
  state: () => {
    return {
      userInfo: {}
    }
  },

  // 可以在这里定义一些方法
  actions: {
    // 设置用户信息
    setUserInfo(userInfo) {
      ;(this.userInfo = userInfo), localStorage.setItem('userInfo', JSON.stringify(userInfo))
    },

    //获取用户信息
    getUserInfo() {
      return this.userInfo
    },

    // 清除用户信息
    clearUserInfo() {
      this.userInfo = null
    }
  }
})
