import { defineStore } from 'pinia'
export const useGlobalStore = defineStore({
  id: 'globalStore',

  state: () => {
    return {
      globalStore: {}
    }
  },
  actions: {
    setGlobalStore(key, value) {
      this.globalStore[key] = value
    },

    getGlobalStore(key) {
      return this.globalStore[key]
    }
  }
})
