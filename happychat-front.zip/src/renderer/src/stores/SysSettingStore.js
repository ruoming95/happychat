import { defineStore } from 'pinia'
export const useSysSettingStore = defineStore({
  id: 'sysSetting',

  state: () => {
    return {
      sysSetting: {}
    }
  },
  actions: {
    setSetting(value) {
      this.sysSetting = value
    },

    getSetting() {
      return this.sysSetting
    }
  }
})
