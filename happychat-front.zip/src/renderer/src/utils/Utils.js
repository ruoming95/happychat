import moment from 'moment'

let datelist = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']

const isEmpty = (str) => {
  if (str == null || str == undefined || str == '') {
    return true
  }
  return false
}

const getAreaInfo = (data) => {
  if (isEmpty(data)) {
    return '-'
  }
  return data.replace(',', ' ')
}

const formatDate = (timestamp) => {
  const timestampTime = moment(timestamp)
  const days =
    Number.parseInt(moment().format('YYYYMMDD')) - Number.parseInt(timestampTime.format('YYYYMMDD'))
  if (days == 0) {
    return timestampTime.format('HH:mm')
  } else if (days == 1) {
    return '昨天'
  } else if (days >= 2 && days < 7) {
    return datelist[new Date(timestamp).getDay()]
    // return timestampTime.format('dddd')
  } else if (days >= 7) {
    return timestampTime.format('YY-MM-DD')
  }
}

const formatFileSize = (bytes) => {
  if (bytes === 0 || bytes == null) return '0 B'

  const units = ['B', 'KB', 'MB', 'GB']
  let unitIndex = 0

  while (bytes >= 1024 && unitIndex < units.length - 1) {
    bytes /= 1024
    unitIndex++
  }

  return `${bytes.toFixed(2)} ${units[unitIndex]}`
}

export default {
  isEmpty,
  getAreaInfo,
  formatDate,
  formatFileSize
}
