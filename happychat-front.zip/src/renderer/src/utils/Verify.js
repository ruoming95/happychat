const reg = {
  email: /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/,
  number: /^[1-9][0-9]*$/,
  password: /^[\w!@#$%^&*()_+-=\[\]{};:',<.>\/?]{6,16}$/,
  version: /^[0-9\.]+$/,
  link: /^(https?:\/\/)?((([a-z\d]([a-z\d-]*[a-z\d])*)\.)+[a-z]{2,}|((\d{1,3}\.){3}\d{1,3})|localhost)(:\d+)?(\/[-a-z\d%_.~+]*)*(\?[;&a-z\d%_.~+=-]*)?(\#[-a-z\d_]*)?$/i
}

const verify = (rule, value, reg, callback) => {
  if (value) {
    if (reg.test(value)) {
      callback()
    } else {
      callback(new Error(rule.message))
    }
  } else {
    callback()
  }
}

const checkPassword = (value) => {
  return reg.password.test(value)
}

const checkLink = (value) => {
  return reg.link.test(value)
}

const checkEmail = (value) => {
  return reg.email.test(value)
}

const password = (rule, value, callback) => {
  return verify(rule, value, reg.password, callback)
}

const number = (rule, value, callback) => {
  return verify(rule, value, reg.number, callback)
}

export default {
  checkPassword,
  checkEmail,
  password,
  number,
  checkLink
}
