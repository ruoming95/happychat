import { ElMessageBox } from 'element-plus'

const confirm = ({ message, okfun, showCancelBtn = true, okText = '确定' }) => {
  ElMessageBox.confirm(message, '提示', {
    'close-on-click-modal': false,
    confirmButtonText: okText,
    cancelButtonText: '取消',
    showCancelButton: showCancelBtn,
    type: 'info'
  })
    .then(async () => {
      if (okfun) {
        okfun()
      }
    })
    .catch(() => {
      // 可以在这里处理取消操作或其他错误处理
    })
}

export default confirm
