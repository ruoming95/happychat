//文件类型
const FILE_TYPE = {
  jpeg: 0,
  jpg: 0,
  png: 0,
  gif: 0,
  bmp: 0,
  webp: 0,
  mp4: 1,
  avi: 1,
  mkv: 1,
  mov: 1,
  mp3: 2,
  wav: 2,
  ogg: 2,
  flac: 2,
  0: '图片',
  1: '视频',
  2: '音频',
  3: '文件'
}

const getFileType = (suffix) => {
  if (suffix == undefined) {
    return 3
  }
  if (typeof suffix == 'string') {
    suffix = suffix.toLowerCase()
  }

  const fileType = FILE_TYPE[suffix]
  return fileType == undefined ? 3 : fileType
}

export { getFileType }
