<template>
  <div class="win-op no-drag">
    <div
      v-if="showSetTop"
      :class="['iconfont icon-top', isTop ? 'win-top' : '']"
      @click="top"
      :title="isTop ? '取消置顶' : '置顶'"
    ></div>
    <div v-if="showMin" class="iconfont icon-min" @click="minimize" title="最小化"></div>
    <div
      v-if="showMax"
      :class="['iconfont', isMax ? 'icon-maximize' : 'icon-max']"
      @click="maximize"
      :title="isMax ? '向下还原' : '最大化'"
    ></div>
    <div v-if="showClose" class="iconfont icon-close" @click="close" title="关闭"></div>
  </div>
</template>

<script setup>
import { ref, reactive, getCurrentInstance, nextTick, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
const { proxy } = getCurrentInstance()
const route = useRoute()
const router = useRouter()

const props = defineProps({
  showSetTop: {
    type: Boolean,
    default: true
  },
  showMin: {
    type: Boolean,
    default: true
  },
  showMax: {
    type: Boolean,
    default: true
  },
  showClose: {
    type: Boolean,
    default: true
  },
  //0 关闭 1隐藏
  closeType: {
    type: Number,
    default: 1
  }
})

const emit = defineEmits(['closeCallback'])

const isMax = ref(false)
const isTop = ref(false)

const winOp = (action, data) => {
  window.ipcRenderer.send('winTitleOp', { action, data })
}

const top = () => {
  isTop.value = !isTop.value
  winOp('top', { top: isTop.value })
}

const close = () => {
  if (props.closeType == 0) {
    proxy.Confirm({
      message: '确定要退出应用吗?',
      okfun: async () => {
        winOp('close', { closeType: props.closeType })
      }
    })
    return
  }
  winOp('close', { closeType: props.closeType })
  emit('closeCallback')
}

const minimize = () => {
  winOp('minimize')
}

const maximize = () => {
  if (isMax.value) {
    winOp('unmaximize')
    isMax.value = false
  } else {
    winOp('maximize')
    isMax.value = true
  }
}
onMounted(() => {
  isMax.value = false
  isTop.value = false
})
</script>

<style lang="scss" scoped>
.win-op {
  top: 0px;
  right: 0px;
  position: absolute;
  z-index: 1;
  overflow: hidden;
  border-radius: 0px 3px 0px 0px;
  .iconfont {
    float: left;
    font-size: 12px;
    color: #101010;
    text-align: center;
    display: flex;
    justify-content: center;
    cursor: pointer;
    height: 25px;
    align-items: center;
    padding: 0px 10px;
    &:hover {
      background-color: #ccc;
    }
  }

  .icon-close {
    &:hover {
      background-color: #fb7373;
      color: #fff;
    }
  }

  .win-top {
    background-color: #ddd;
    color: #07c160;
  }
}
</style>
