<template>
  <div class="top drag"></div>
  <div class="iconfont icon-chat"></div>
</template>

<script setup></script>

<style lang="scss" scoped>
.top {
  height: 60px;
}

.iconfont {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 100px;
  color: #ddd;
  height: calc(100vh - 122px);
}
</style>
