<template>
  <div v-show="showPlay">
    <audio
      ref="audioPlayRef"
      :src="serverUrl"
      controls
      @timeupdate="updateProgress"
      @loadedmetadata="setDuration"
      @seeking="dragProgress"
      @seeked="seek"
    ></audio>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useGlobalStore } from '@/stores/GlobalStore'
const globalStore = useGlobalStore()
const audioPlayRef = ref(null)

const props = defineProps({
  showPlay: {
    type: Boolean,
    default: true
  },
  fileId: {
    type: [String, Number],
    default: 0
  },
  partType: {
    type: String,
    default: 'notify'
  },
  fileType: {
    type: Number,
    default: 2
  }
})

const play = () => {
  if (audioPlayRef.value) {
    audioPlayRef.value.play()
  }
}

const serverUrl = computed(() => {
  const serverPort = globalStore.getGlobalStore('localServerPort')
  let url = `http://127.0.0.1:${serverPort}/file?fileId=${props.fileId}&partType=${props.partType}&fileType=${props.fileType}&${new Date().getTime()}`
  console.log(url)
  return url
})

const updateProgress = () => {
  // console.log('当前播放时间', audioPlayRef.value.currentTime)
}

const emit = defineEmits(['showLoading'])
const setDuration = () => {}

const dragProgress = () => {
  // console.log('拖动进度条')
}

const seek = () => {
  // console.log('当前播放时间', audioPlayRef.value.currentTime)
}

defineExpose({
  play
})
</script>

<style scoped>
:deep(audio) {
  width: 250px;
  height: 30px;
}
</style>
