<template>
  <div>
    <AvatarBase
      :userId="userId"
      :width="width"
      :borderRadius="borderRadius"
      :showDetail="false"
      v-if="userId == 'Uroboot'"
    >
    </AvatarBase>
    <el-popover
      v-else
      :width="200"
      :placement="right - start"
      :show-arrow="false"
      trigger="click"
      transition="none"
      :hide-after="0"
      @show="getContactInfo"
      ref="popoverRef"
    >
      <template #reference>
        <AvatarBase
          :userId="userId"
          :width="width"
          :borderRadius="borderRadius"
          :showDetail="false"
        >
        </AvatarBase>
      </template>
      <template #default>
        <div class="popover-user-panel">
          <UserBaseInfo :userInfo="userInfo"></UserBaseInfo>
          <div class="op-btn" v-if="userId != userInfoStore.getUserInfo().userId">
            <el-button v-if="userInfo.contactStatus == 1" type="primary" @click="sendMessage"
              >发送消息</el-button
            ><el-button v-else type="primary" @click="addContact">添加好友</el-button>
          </div>
        </div>
      </template>
    </el-popover>
    <SearchAdd ref="searChAddRef"></SearchAdd>
  </div>
</template>

<script setup>
import AvatarBase from './AvatarBase.vue'
import SearchAdd from '@/views/contact/SearchAdd.vue'
import UserBaseInfo from './UserBaseInfo.vue'
import { useUserInfoStore } from '@/stores/UserInfoStore'
import { ref, reactive, getCurrentInstance, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
const route = useRoute()
const router = useRouter()
const userInfoStore = useUserInfoStore()
const { proxy } = getCurrentInstance()

const popoverRef = ref()

const props = defineProps({
  userId: {
    type: String
  },
  width: {
    type: Number,
    default: 40
  },
  borderRadius: {
    type: Number,
    default: 0
  },
  showDetail: {
    type: Boolean,
    default: false
  },
  groupId: {
    type: String
  }
})

const userInfo = ref({})
const getContactInfo = async () => {
  userInfo.value.userId = props.userId
  if (userInfoStore.getUserInfo().userId == props.userId) {
    userInfo.value = userInfoStore.getUserInfo()
  } else {
    let result = await proxy.Request({
      url: proxy.Api.getContactInfo,
      params: {
        contactId: props.userId
      },
      showLoading: false
    })
    if (!result) {
      return
    }
    userInfo.value = Object.assign({}, result.data)
  }
}

const sendMessage = () => {
  popoverRef.value.hide()
  router.push({
    path: '/chat',
    query: {
      chatId: props.userId,
      timestamp: new Date().getTime()
    }
  })
}

const searChAddRef = ref()
const addContact = () => {
  popoverRef.value.hide()
  searChAddRef.value.show({
    contactId: props.userId,
    contactType: 'USER'
  })
}
</script>

<style lang="scss" scoped>
.op-btn {
  text-align: center;
  border-top: 1px solid #eaeaea;
  padding-top: 10px;
}
</style>
