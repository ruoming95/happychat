<template>
  <div>
    <el-cascader
      :options="provinceAndCityData"
      v-model="modelValue.areaCode"
      @change="change"
      ref="areaSelectRef"
      clearable
      placeholder="请选择地区"
    ></el-cascader>
  </div>
</template>

<script setup>
import { ref, reactive, getCurrentInstance, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { provinceAndCityData } from 'element-china-area-data'
const { proxy } = getCurrentInstance()
const route = useRoute()
const router = useRouter()

const props = defineProps({
  modelValue: {
    type: Object,
    default: {}
  }
})

const emit = defineEmits(['update:modelValue'])
const areaSelectRef = ref()
const change = (e) => {
  const areaData = {
    areaName: [],
    areaCode: []
  }
  const selectedNodes = areaSelectRef.value.getCheckedNodes()[0]
  if (!selectedNodes) {
    emit('update:modelValue', areaData)
    return
  }
  const pathValues = selectedNodes.pathValues
  const pathLabels = selectedNodes.pathLabels
  areaData.areaName = pathLabels[0] + ',' + pathLabels[1]
  areaData.areaCode = pathValues[0] + ',' + pathValues[1]
  emit('update:modelValue', areaData)
}
</script>

<style lang="scss" scoped></style>
