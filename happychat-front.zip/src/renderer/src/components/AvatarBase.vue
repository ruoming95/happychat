<template>
  <div
    class="user-avatar"
    @click="showDetailHandler"
    :style="{
      width: width + 'px',
      height: width + 'px',
      'border-radius': borderRadius + 'px'
    }"
  >
    <ShowLocalImage
      :width="width"
      :fileId="userId"
      partType="avatar"
      :forceGet="avatarStore.getAvatarStore(userId)"
    ></ShowLocalImage>
  </div>
</template>

<script setup>
import { ref, reactive, getCurrentInstance, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAvatarStore } from '@/stores/AvatarStore'
const avatarStore = useAvatarStore()
const { proxy } = getCurrentInstance()
const route = useRoute()
const router = useRouter()

const props = defineProps({
  userId: {
    type: String
  },
  width: {
    type: Number,
    default: 40
  },
  borderRadius: {
    type: Number,
    default: 0
  },
  showDetail: {
    type: Boolean,
    default: false
  }
})

const showDetailHandler = () => {
  if (!props.showDetail) {
    return
  }

  //图片详情
}
// console.log(props)
</script>

<style lang="scss" scoped>
.user-avatar {
  background-color: #d3d3d3;
  display: flex;
  overflow: hidden;
  cursor: pointer;
  align-items: center;
  justify-content: center;
}
</style>
